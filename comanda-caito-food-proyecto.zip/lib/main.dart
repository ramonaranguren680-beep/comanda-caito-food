import 'package:flutter/material.dart';

void main() {
  runApp(const ComandaCaitoFoodApp());
}

// ============================================================================
// COLORES CORPORATIVOS: VERDE OSCURO, BLANCO Y DORADO
// ============================================================================
class AppColors {
  static const Color primaryGreen = Color(0xFF0F3D2E);
  static const Color darkGreen = Color(0xFF09261D);
  static const Color lightGreen = Color(0xFFE8F2EE);
  static const Color gold = Color(0xFFD4AF37);
  static const Color goldLight = Color(0xFFFBF6E4);
  static const Color white = Color(0xFFFFFFFF);
  static const Color background = Color(0xFFF4F6F5);
  static const Color textDark = Color(0xFF1A2421);
  static const Color danger = Color(0xFFC62828);
}

// ============================================================================
// MODELOS DE DATOS MULTI-RESTAURANTE
// ============================================================================
enum UserRole { superadmin, admin, cajero, cocina }

enum OrderStatus { pendiente, enPreparacion, listo, entregado, anulado }

class Restaurant {
  final String id;
  final String name;
  final String address;
  bool isActive;
  int orderCounter;

  Restaurant({
    required this.id,
    required this.name,
    required this.address,
    this.isActive = true,
    this.orderCounter = 0,
  });
}

class ProductItem {
  final String id;
  final String category;
  final String name;
  final double basePrice;
  final bool requiresProtein;
  final bool requiresFries;
  final bool requiresBroasterOpts;
  final bool allowsCreams;
  final Map<String, double> recipe; // ingredienteId -> cantidad

  ProductItem({
    required this.id,
    required this.category,
    required this.name,
    required this.basePrice,
    this.requiresProtein = false,
    this.requiresFries = false,
    this.requiresBroasterOpts = false,
    this.allowsCreams = true,
    required this.recipe,
  });
}

class OrderLine {
  final String productId;
  final String productName;
  int quantity;
  final double unitPrice;
  final String? protein;
  final String? fries;
  final String? broasterRice;
  final String? broasterSalad;
  final List<String> creams;
  final String quickNote;
  final Map<String, double> totalRecipePerUnit;

  OrderLine({
    required this.productId,
    required this.productName,
    required this.quantity,
    required this.unitPrice,
    this.protein,
    this.fries,
    this.broasterRice,
    this.broasterSalad,
    required this.creams,
    this.quickNote = '',
    required this.totalRecipePerUnit,
  });

  double get subtotal => unitPrice * quantity;
}

class CustomerOrder {
  final String id;
  final String restaurantId;
  final int orderNumber;
  final bool isTakeaway;
  final String tableOrClient;
  final String paymentMethod;
  final List<OrderLine> items;
  final DateTime createdAt;
  final String createdBy;
  OrderStatus status;
  String? cancelReason;

  CustomerOrder({
    required this.id,
    required this.restaurantId,
    required this.orderNumber,
    required this.isTakeaway,
    required this.tableOrClient,
    required this.paymentMethod,
    required this.items,
    required this.createdAt,
    required this.createdBy,
    this.status = OrderStatus.pendiente,
    this.cancelReason,
  });

  double get total => items.fold(0, (sum, item) => sum + item.subtotal);
}

class InventoryItem {
  final String id;
  final String name;
  final String unit;
  double stock;
  final double minAlert;

  InventoryItem({
    required this.id,
    required this.name,
    required this.unit,
    required this.stock,
    required this.minAlert,
  });
}

class InventoryLog {
  final DateTime date;
  final String itemName;
  final String type;
  final double change;
  final double stockAfter;
  final String user;

  InventoryLog({
    required this.date,
    required this.itemName,
    required this.type,
    required this.change,
    required this.stockAfter,
    required this.user,
  });
}

// ============================================================================
// APLICACIÓN PRINCIPAL
// ============================================================================
class ComandaCaitoFoodApp extends StatelessWidget {
  const ComandaCaitoFoodApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Comanda Caito Food',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.primaryGreen,
          primary: AppColors.primaryGreen,
          secondary: AppColors.gold,
          surface: AppColors.white,
        ),
        scaffoldBackgroundColor: AppColors.background,
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.primaryGreen,
          foregroundColor: AppColors.white,
          elevation: 0,
        ),
      ),
      home: const LoginScreen(),
    );
  }
}

// ============================================================================
// PANTALLA DE INICIO DE SESIÓN Y SELECCIÓN DE ROL / LOCAL
// ============================================================================
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _userCtrl = TextEditingController(text: 'admin');
  final TextEditingController _passCtrl = TextEditingController(text: '1234');
  UserRole _selectedRole = UserRole.cajero;
  String _selectedRestaurantId = 'rest_1';

  final List<Restaurant> _restaurants = [
    Restaurant(id: 'rest_1', name: 'Caito Food - Sede Central', address: 'Av. Principal 120'),
    Restaurant(id: 'rest_2', name: 'Caito Food - Sede Norte', address: 'Jr. Los Olivos 450'),
  ];

  void _login() {
    if (_userCtrl.text.trim().isEmpty || _passCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ingrese usuario y contraseña')),
      );
      return;
    }
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => MainPosShell(
          restaurants: _restaurants,
          initialRestaurantId: _selectedRestaurantId,
          initialRole: _selectedRole,
          username: _userCtrl.text.trim(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primaryGreen,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Card(
              color: AppColors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              elevation: 8,
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppColors.primaryGreen,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppColors.gold, width: 2),
                      ),
                      child: const Icon(Icons.restaurant_menu, size: 48, color: AppColors.gold),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'COMANDA CAITO FOOD',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        color: AppColors.primaryGreen,
                        letterSpacing: 1,
                      ),
                    ),
                    const Text(
                      'Sistema POS Multi-Restaurante',
                      style: TextStyle(color: Colors.grey, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 24),
                    DropdownButtonFormField<String>(
                      value: _selectedRestaurantId,
                      decoration: const InputDecoration(
                        labelText: 'Restaurante',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.store, color: AppColors.primaryGreen),
                      ),
                      items: _restaurants
                          .map((r) => DropdownMenuItem(value: r.id, child: Text(r.name)))
                          .toList(),
                      onChanged: (v) => setState(() => _selectedRestaurantId = v!),
                    ),
                    const SizedBox(height: 14),
                    DropdownButtonFormField<UserRole>(
                      value: _selectedRole,
                      decoration: const InputDecoration(
                        labelText: 'Rol de Acceso',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.badge, color: AppColors.primaryGreen),
                      ),
                      items: const [
                        DropdownMenuItem(value: UserRole.superadmin, child: Text('Superadministrador')),
                        DropdownMenuItem(value: UserRole.admin, child: Text('Administrador / Dueño')),
                        DropdownMenuItem(value: UserRole.cajero, child: Text('Cajero (Comandas)')),
                        DropdownMenuItem(value: UserRole.cocina, child: Text('Cocina (Pedidos)')),
                      ],
                      onChanged: (v) => setState(() => _selectedRole = v!),
                    ),
                    const SizedBox(height: 14),
                    TextField(
                      controller: _userCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Usuario',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.person, color: AppColors.primaryGreen),
                      ),
                    ),
                    const SizedBox(height: 14),
                    TextField(
                      controller: _passCtrl,
                      obscureText: true,
                      decoration: const InputDecoration(
                        labelText: 'Contraseña',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.lock, color: AppColors.primaryGreen),
                      ),
                    ),
                    const SizedBox(height: 22),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primaryGreen,
                          foregroundColor: AppColors.gold,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        onPressed: _login,
                        child: const Text(
                          'INGRESAR AL SISTEMA',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================================
// CONTENEDOR PRINCIPAL MULTI-TENANT
// ============================================================================
class MainPosShell extends StatefulWidget {
  final List<Restaurant> restaurants;
  final String initialRestaurantId;
  final UserRole initialRole;
  final String username;

  const MainPosShell({
    super.key,
    required this.restaurants,
    required this.initialRestaurantId,
    required this.initialRole,
    required this.username,
  });

  @override
  State<MainPosShell> createState() => _MainPosShellState();
}

class _MainPosShellState extends State<MainPosShell> {
  late String _currentRestaurantId;
  late UserRole _currentRole;
  int _tabIndex = 0;

  // Datos aislados por restaurante_id
  final Map<String, List<CustomerOrder>> _ordersByRest = {};
  final Map<String, List<InventoryItem>> _inventoryByRest = {};
  final Map<String, List<InventoryLog>> _logsByRest = {};
  final List<OrderLine> _currentCart = [];

  static const List<String> allCreams = [
    'Mayonesa',
    'Ketchup',
    'Ají rocoto',
    'Ají de pollería',
    'Golf',
    'Tártara',
    'Mostaza',
    'Aceituna',
    'Tocino',
    'Agua y manto',
  ];

  // MENÚ OFICIAL DE CAITO FOOD (32 PRODUCTOS)
  final List<ProductItem> _menu = [
    // AL PLATO
    ProductItem(id: 'p1', category: 'AL PLATO', name: 'Salchipapa', basePrice: 13.0, recipe: {'papa': 0.30, 'salchicha': 2, 'aceite': 0.05}),
    ProductItem(id: 'p2', category: 'AL PLATO', name: 'Salchipapa especial', basePrice: 16.0, recipe: {'papa': 0.35, 'salchicha': 3, 'aceite': 0.06}),
    ProductItem(id: 'p3', category: 'AL PLATO', name: 'Salchipapa amazónica', basePrice: 20.0, recipe: {'papa': 0.35, 'salchicha': 3, 'aceite': 0.06}),
    ProductItem(id: 'p4', category: 'AL PLATO', name: 'Burger Order', basePrice: 24.0, requiresFries: true, recipe: {'carne': 1, 'papa': 0.25, 'aceite': 0.05}),
    ProductItem(id: 'p5', category: 'AL PLATO', name: 'Suprema Order', basePrice: 24.0, requiresFries: true, recipe: {'pollo': 0.25, 'papa': 0.25, 'aceite': 0.05}),
    ProductItem(id: 'p6', category: 'AL PLATO', name: 'Salchibroaster', basePrice: 22.0, requiresBroasterOpts: true, recipe: {'pollo': 0.25, 'salchicha': 2, 'papa': 0.25, 'aceite': 0.08}),
    ProductItem(id: 'p7', category: 'AL PLATO', name: 'Broaster pecho 1/4', basePrice: 15.0, requiresBroasterOpts: true, recipe: {'pollo': 0.30, 'papa': 0.25, 'aceite': 0.08}),
    ProductItem(id: 'p8', category: 'AL PLATO', name: 'Broaster pierna 1/4', basePrice: 15.0, requiresBroasterOpts: true, recipe: {'pollo': 0.28, 'papa': 0.25, 'aceite': 0.08}),
    ProductItem(id: 'p9', category: 'AL PLATO', name: 'Alitas x 6', basePrice: 14.0, recipe: {'alitas': 6, 'papa': 0.20, 'aceite': 0.06}),
    ProductItem(id: 'p10', category: 'AL PLATO', name: 'Alita broaster', basePrice: 14.0, requiresBroasterOpts: true, recipe: {'alitas': 4, 'papa': 0.20, 'aceite': 0.07}),

    // SÁNDWICHES (Todos exigen proteína excepto Suprema clásica; todos exigen tipo de papas)
    ProductItem(id: 's1', category: 'SÁNDWICHES', name: 'Clásica', basePrice: 13.0, requiresProtein: true, requiresFries: true, recipe: {'papa': 0.20, 'aceite': 0.04}),
    ProductItem(id: 's2', category: 'SÁNDWICHES', name: 'Cheese', basePrice: 14.0, requiresProtein: true, requiresFries: true, recipe: {'papa': 0.20, 'aceite': 0.04}),
    ProductItem(id: 's3', category: 'SÁNDWICHES', name: 'Royal', basePrice: 15.0, requiresProtein: true, requiresFries: true, recipe: {'papa': 0.20, 'aceite': 0.04}),
    ProductItem(id: 's4', category: 'SÁNDWICHES', name: 'Queso tocino', basePrice: 15.0, requiresProtein: true, requiresFries: true, recipe: {'papa': 0.20, 'aceite': 0.04}),
    ProductItem(id: 's5', category: 'SÁNDWICHES', name: 'Año pobre', basePrice: 15.0, requiresProtein: true, requiresFries: true, recipe: {'papa': 0.20, 'aceite': 0.04}),
    ProductItem(id: 's6', category: 'SÁNDWICHES', name: 'Mexicana', basePrice: 15.0, requiresProtein: true, requiresFries: true, recipe: {'papa': 0.20, 'aceite': 0.04}),
    ProductItem(id: 's7', category: 'SÁNDWICHES', name: 'Parrillera', basePrice: 17.0, requiresProtein: true, requiresFries: true, recipe: {'papa': 0.20, 'aceite': 0.04}),
    ProductItem(id: 's8', category: 'SÁNDWICHES', name: 'Hawaiana', basePrice: 17.0, requiresProtein: true, requiresFries: true, recipe: {'papa': 0.20, 'aceite': 0.04}),
    ProductItem(id: 's9', category: 'SÁNDWICHES', name: 'Suprema clásica', basePrice: 16.0, requiresProtein: false, requiresFries: true, recipe: {'pollo': 0.20, 'papa': 0.20, 'aceite': 0.04}),

    // TACOS Y ENCHILADAS (Exigen tipo de papas)
    ProductItem(id: 't1', category: 'TACOS Y ENCHILADAS', name: 'Taco de pollo', basePrice: 16.0, requiresFries: true, recipe: {'pollo': 0.18, 'papa': 0.20, 'aceite': 0.03}),
    ProductItem(id: 't2', category: 'TACOS Y ENCHILADAS', name: 'Taco de carne', basePrice: 16.0, requiresFries: true, recipe: {'carne': 1, 'papa': 0.20, 'aceite': 0.03}),
    ProductItem(id: 't3', category: 'TACOS Y ENCHILADAS', name: 'Taco mixto', basePrice: 18.0, requiresFries: true, recipe: {'pollo': 0.10, 'carne': 0.5, 'papa': 0.20, 'aceite': 0.03}),
    ProductItem(id: 't4', category: 'TACOS Y ENCHILADAS', name: 'Enchilada de pollo', basePrice: 16.0, requiresFries: true, recipe: {'pollo': 0.18, 'papa': 0.20, 'aceite': 0.03}),
    ProductItem(id: 't5', category: 'TACOS Y ENCHILADAS', name: 'Enchilada de carne', basePrice: 16.0, requiresFries: true, recipe: {'carne': 1, 'papa': 0.20, 'aceite': 0.03}),
    ProductItem(id: 't6', category: 'TACOS Y ENCHILADAS', name: 'Enchilada mixta', basePrice: 18.0, requiresFries: true, recipe: {'pollo': 0.10, 'carne': 0.5, 'papa': 0.20, 'aceite': 0.03}),

    // BEBIDAS
    ProductItem(id: 'b1', category: 'BEBIDAS', name: 'Gaseosa 1/2 litro', basePrice: 4.50, allowsCreams: false, recipe: {'bebidas': 1}),
    ProductItem(id: 'b2', category: 'BEBIDAS', name: 'Gaseosa 300 ml vidrio', basePrice: 3.50, allowsCreams: false, recipe: {'bebidas': 1}),
    ProductItem(id: 'b3', category: 'BEBIDAS', name: 'Chicha morada', basePrice: 5.90, allowsCreams: false, recipe: {'bebidas': 1}),
    ProductItem(id: 'b4', category: 'BEBIDAS', name: 'Maracuyá', basePrice: 4.90, allowsCreams: false, recipe: {'bebidas': 1}),
    ProductItem(id: 'b5', category: 'BEBIDAS', name: 'Emoliente', basePrice: 4.90, allowsCreams: false, recipe: {'bebidas': 1}),
    ProductItem(id: 'b6', category: 'BEBIDAS', name: 'Café', basePrice: 4.90, allowsCreams: false, recipe: {'bebidas': 1}),
    ProductItem(id: 'b7', category: 'BEBIDAS', name: 'Infusiones', basePrice: 4.90, allowsCreams: false, recipe: {'bebidas': 1}),
  ];

  @override
  void initState() {
    super.initState();
    _currentRestaurantId = widget.initialRestaurantId;
    _currentRole = widget.initialRole;
    for (final r in widget.restaurants) {
      _initTenantData(r.id);
    }
    if (_currentRole == UserRole.cocina) {
      _tabIndex = 1;
    }
  }

  void _initTenantData(String restId) {
    _ordersByRest.putIfAbsent(restId, () => []);
    _logsByRest.putIfAbsent(restId, () => []);
    _inventoryByRest.putIfAbsent(
      restId,
      () => [
        InventoryItem(id: 'papa', name: 'Papa', unit: 'kg', stock: 45.0, minAlert: 10.0),
        InventoryItem(id: 'pollo', name: 'Pollo', unit: 'kg', stock: 30.0, minAlert: 8.0),
        InventoryItem(id: 'carne', name: 'Carne Hamburguesa', unit: 'und', stock: 60.0, minAlert: 15.0),
        InventoryItem(id: 'alitas', name: 'Alitas de Pollo', unit: 'und', stock: 120.0, minAlert: 24.0),
        InventoryItem(id: 'salchicha', name: 'Salchichas', unit: 'und', stock: 80.0, minAlert: 20.0),
        InventoryItem(id: 'aceite', name: 'Aceite Vegetal', unit: 'lt', stock: 20.0, minAlert: 5.0),
        InventoryItem(id: 'bebidas', name: 'Bebidas / Vasos', unit: 'und', stock: 90.0, minAlert: 15.0),
        InventoryItem(id: 'envase', name: 'Envase Para Llevar', unit: 'und', stock: 100.0, minAlert: 20.0),
      ],
    );
  }

  Restaurant get _activeRestaurant =>
      widget.restaurants.firstWhere((r) => r.id == _currentRestaurantId);

  List<CustomerOrder> get _orders => _ordersByRest[_currentRestaurantId]!;
  List<InventoryItem> get _inventory => _inventoryByRest[_currentRestaurantId]!;
  List<InventoryLog> get _logs => _logsByRest[_currentRestaurantId]!;

  // ==========================================================================
  // MODAL DE PERSONALIZACIÓN OBLIGATORIA (SIN ESCRIBIR MANUALMENTE)
  // ==========================================================================
  void _openProductCustomizer(ProductItem product) {
    String? selectedProtein;
    String? selectedFries;
    String? broasterRice;
    String? broasterSalad;
    final Set<String> selectedCreams = {};
    int qty = 1;
    final TextEditingController noteCtrl = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModalState) {
            final bool validProtein = !product.requiresProtein || selectedProtein != null;
            final bool validFries = !product.requiresFries || selectedFries != null;
            final bool validBroaster = !product.requiresBroasterOpts ||
                (broasterRice != null && broasterSalad != null);
            final bool canConfirm = validProtein && validFries && validBroaster;

            final double extraSuprema = (selectedProtein == 'Suprema') ? 3.0 : 0.0;
            final double unitPrice = product.basePrice + extraSuprema;

            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 16,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
              ),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Center(
                      child: Container(
                        width: 44,
                        height: 5,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            product.name,
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                              color: AppColors.primaryGreen,
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: AppColors.primaryGreen,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            'S/ ${(unitPrice * qty).toStringAsFixed(2)}',
                            style: const TextStyle(
                              color: AppColors.gold,
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: 24),

                    if (product.requiresProtein) ...[
                      _sectionTitle('1. PROTEÍNA (OBLIGATORIO)', validProtein),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: ['Carne', 'Pollo deshilachado', 'Filete de pollo', 'Suprema']
                            .map((opt) {
                          final selected = selectedProtein == opt;
                          final label = opt == 'Suprema' ? 'Suprema (+S/ 3.00)' : opt;
                          return ChoiceChip(
                            label: Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
                            selected: selected,
                            selectedColor: AppColors.primaryGreen,
                            labelStyle: TextStyle(
                              color: selected ? AppColors.gold : AppColors.textDark,
                            ),
                            onSelected: (_) => setModalState(() => selectedProtein = opt),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 16),
                    ],

                    if (product.requiresFries) ...[
                      _sectionTitle('TIPO DE PAPAS (OBLIGATORIO)', validFries),
                      const SizedBox(height: 8),
                      Row(
                        children: ['Papas fritas', 'Papas al hilo'].map((opt) {
                          final selected = selectedFries == opt;
                          return Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 4),
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor:
                                      selected ? AppColors.primaryGreen : Colors.grey.shade200,
                                  foregroundColor:
                                      selected ? AppColors.gold : AppColors.textDark,
                                  padding: const EdgeInsets.symmetric(vertical: 14),
                                ),
                                onPressed: () => setModalState(() => selectedFries = opt),
                                child: Text(opt, style: const TextStyle(fontWeight: FontWeight.bold)),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 16),
                    ],

                    if (product.requiresBroasterOpts) ...[
                      _sectionTitle('ARROZ (OBLIGATORIO)', broasterRice != null),
                      const SizedBox(height: 8),
                      Row(
                        children: ['Con arroz', 'Sin arroz'].map((opt) {
                          final selected = broasterRice == opt;
                          return Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 4),
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor:
                                      selected ? AppColors.primaryGreen : Colors.grey.shade200,
                                  foregroundColor:
                                      selected ? AppColors.gold : AppColors.textDark,
                                  padding: const EdgeInsets.symmetric(vertical: 14),
                                ),
                                onPressed: () => setModalState(() => broasterRice = opt),
                                child: Text(opt, style: const TextStyle(fontWeight: FontWeight.bold)),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 14),
                      _sectionTitle('ENSALADA (OBLIGATORIO)', broasterSalad != null),
                      const SizedBox(height: 8),
                      Row(
                        children: ['Con ensalada', 'Sin ensalada'].map((opt) {
                          final selected = broasterSalad == opt;
                          return Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 4),
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor:
                                      selected ? AppColors.primaryGreen : Colors.grey.shade200,
                                  foregroundColor:
                                      selected ? AppColors.gold : AppColors.textDark,
                                  padding: const EdgeInsets.symmetric(vertical: 14),
                                ),
                                onPressed: () => setModalState(() => broasterSalad = opt),
                                child: Text(opt, style: const TextStyle(fontWeight: FontWeight.bold)),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 16),
                    ],

                    if (product.allowsCreams) ...[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'CREMAS Y COMPLEMENTOS',
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                          ),
                          TextButton(
                            onPressed: () {
                              setModalState(() {
                                if (selectedCreams.length == allCreams.length) {
                                  selectedCreams.clear();
                                } else {
                                  selectedCreams.addAll(allCreams);
                                }
                              });
                            },
                            child: Text(
                              selectedCreams.length == allCreams.length ? 'Quitar todas' : 'Todas',
                            ),
                          ),
                        ],
                      ),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: allCreams.map((cream) {
                          final isSelected = selectedCreams.contains(cream);
                          return FilterChip(
                            label: Text(cream, style: const TextStyle(fontWeight: FontWeight.w600)),
                            selected: isSelected,
                            selectedColor: AppColors.goldLight,
                            checkmarkColor: AppColors.primaryGreen,
                            side: BorderSide(
                              color: isSelected ? AppColors.gold : Colors.grey.shade300,
                              width: isSelected ? 2 : 1,
                            ),
                            onSelected: (val) {
                              setModalState(() {
                                if (val) {
                                  selectedCreams.add(cream);
                                } else {
                                  selectedCreams.remove(cream);
                                }
                              });
                            },
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 14),
                    ],

                    TextField(
                      controller: noteCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Observación rápida (opcional)',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                    const SizedBox(height: 16),

                    Row(
                      children: [
                        IconButton.filled(
                          style: IconButton.styleFrom(backgroundColor: AppColors.primaryGreen),
                          onPressed: qty > 1 ? () => setModalState(() => qty--) : null,
                          icon: const Icon(Icons.remove, color: AppColors.white),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: Text(
                            '$qty',
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                        ),
                        IconButton.filled(
                          style: IconButton.styleFrom(backgroundColor: AppColors.primaryGreen),
                          onPressed: () => setModalState(() => qty++),
                          icon: const Icon(Icons.add, color: AppColors.white),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: SizedBox(
                            height: 52,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor:
                                    canConfirm ? AppColors.primaryGreen : Colors.grey.shade400,
                                foregroundColor: AppColors.gold,
                              ),
                              onPressed: canConfirm
                                  ? () {
                                      final recipeCopy = Map<String, double>.from(product.recipe);
                                      if (selectedProtein == 'Carne') {
                                        recipeCopy['carne'] = (recipeCopy['carne'] ?? 0) + 1;
                                      } else if (selectedProtein != null) {
                                        recipeCopy['pollo'] = (recipeCopy['pollo'] ?? 0) + 0.18;
                                      }
                                      setState(() {
                                        _currentCart.add(
                                          OrderLine(
                                            productId: product.id,
                                            productName: product.name,
                                            quantity: qty,
                                            unitPrice: unitPrice,
                                            protein: selectedProtein,
                                            fries: selectedFries,
                                            broasterRice: broasterRice,
                                            broasterSalad: broasterSalad,
                                            creams: selectedCreams.toList(),
                                            quickNote: noteCtrl.text.trim(),
                                            totalRecipePerUnit: recipeCopy,
                                          ),
                                        );
                                      });
                                      Navigator.pop(ctx);
                                    }
                                  : null,
                              child: Text(
                                canConfirm ? 'AGREGAR A COMANDA' : 'COMPLETE OPCIONES',
                                style: const TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _sectionTitle(String title, bool isValid) {
    return Row(
      children: [
        Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 13,
            color: isValid ? AppColors.primaryGreen : AppColors.danger,
          ),
        ),
        const SizedBox(width: 6),
        Icon(
          isValid ? Icons.check_circle : Icons.error_outline,
          size: 16,
          color: isValid ? Colors.green : AppColors.danger,
        ),
      ],
    );
  }

  // ==========================================================================
  // CONFIRMAR COMANDA Y DESCONTAR INVENTARIO AUTOMÁTICAMENTE
  // ==========================================================================
  void _confirmOrderDialog() {
    if (_currentCart.isEmpty) return;
    bool isTakeaway = false;
    final TextEditingController labelCtrl = TextEditingController(text: 'Mesa 1');
    String paymentMethod = 'Efectivo';

    final Map<String, double> needed = {};
    for (final line in _currentCart) {
      line.totalRecipePerUnit.forEach((ingId, qtyPerUnit) {
        needed[ingId] = (needed[ingId] ?? 0) + (qtyPerUnit * line.quantity);
      });
    }

    showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setDialogState) {
            final Map<String, double> finalNeeded = Map.from(needed);
            if (isTakeaway) {
              final totalBoxes = _currentCart.fold<double>(0, (s, l) => s + l.quantity);
              finalNeeded['envase'] = (finalNeeded['envase'] ?? 0) + totalBoxes;
            }

            final List<String> stockWarnings = [];
            finalNeeded.forEach((ingId, req) {
              final inv = _inventory.firstWhere((i) => i.id == ingId);
              if (inv.stock < req) {
                stockWarnings.add('${inv.name} (disp: ${inv.stock.toStringAsFixed(2)})');
              }
            });

            return AlertDialog(
              title: const Text(
                'Confirmar Comanda',
                style: TextStyle(color: AppColors.primaryGreen, fontWeight: FontWeight.bold),
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (stockWarnings.isNotEmpty)
                      Container(
                        padding: const EdgeInsets.all(10),
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: Colors.red.shade50,
                          border: Border.all(color: AppColors.danger),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '⚠️ Alerta de stock insuficiente:
${stockWarnings.join(', ')}',
                          style: const TextStyle(color: AppColors.danger, fontSize: 12),
                        ),
                      ),
                    Row(
                      children: [
                        Expanded(
                          child: ChoiceChip(
                            label: const Center(child: Text('EN MESA')),
                            selected: !isTakeaway,
                            selectedColor: AppColors.primaryGreen,
                            labelStyle: TextStyle(color: !isTakeaway ? AppColors.gold : Colors.black),
                            onSelected: (_) => setDialogState(() {
                              isTakeaway = false;
                              labelCtrl.text = 'Mesa 1';
                            }),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ChoiceChip(
                            label: const Center(child: Text('PARA LLEVAR')),
                            selected: isTakeaway,
                            selectedColor: AppColors.primaryGreen,
                            labelStyle: TextStyle(color: isTakeaway ? AppColors.gold : Colors.black),
                            onSelected: (_) => setDialogState(() {
                              isTakeaway = true;
                              labelCtrl.text = 'Para Llevar';
                            }),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: labelCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Mesa o Nombre del Cliente',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: paymentMethod,
                      decoration: const InputDecoration(
                        labelText: 'Método de Pago',
                        border: OutlineInputBorder(),
                      ),
                      items: ['Efectivo', 'Yape', 'Plin', 'Tarjeta', 'Pendiente']
                          .map((m) => DropdownMenuItem(value: m, child: Text(m)))
                          .toList(),
                      onChanged: (v) => setDialogState(() => paymentMethod = v!),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Cancelar'),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryGreen,
                    foregroundColor: AppColors.gold,
                  ),
                  onPressed: () {
                    setState(() {
                      _activeRestaurant.orderCounter++;
                      final orderNum = _activeRestaurant.orderCounter;

                      finalNeeded.forEach((ingId, req) {
                        final inv = _inventory.firstWhere((i) => i.id == ingId);
                        inv.stock = (inv.stock - req).clamp(0, 999999);
                        _logs.insert(
                          0,
                          InventoryLog(
                            date: DateTime.now(),
                            itemName: inv.name,
                            type: 'Venta Comanda #$orderNum',
                            change: -req,
                            stockAfter: inv.stock,
                            user: widget.username,
                          ),
                        );
                      });

                      _orders.insert(
                        0,
                        CustomerOrder(
                          id: DateTime.now().millisecondsSinceEpoch.toString(),
                          restaurantId: _currentRestaurantId,
                          orderNumber: orderNum,
                          isTakeaway: isTakeaway,
                          tableOrClient: labelCtrl.text.trim(),
                          paymentMethod: paymentMethod,
                          items: List.from(_currentCart),
                          createdAt: DateTime.now(),
                          createdBy: widget.username,
                        ),
                      );
                      _currentCart.clear();
                    });
                    Navigator.pop(ctx);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        backgroundColor: AppColors.primaryGreen,
                        content: Text(
                          'Comanda #${_activeRestaurant.orderCounter} enviada a Cocina e inventario actualizado',
                          style: const TextStyle(color: AppColors.gold),
                        ),
                      ),
                    );
                  },
                  child: const Text('ENVIAR A COCINA'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  // ==========================================================================
  // CONSTRUCCIÓN DE PANTALLAS POR MÓDULO
  // ==========================================================================
  @override
  Widget build(BuildContext context) {
    final pages = [
      _buildPosTab(),
      _buildKitchenTab(),
      _buildInventoryTab(),
      _buildSalesAndAdminTab(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'COMANDA CAITO FOOD',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AppColors.gold),
            ),
            Text(
              '${_activeRestaurant.name} • ${_currentRole.name.toUpperCase()}',
              style: const TextStyle(fontSize: 12, color: AppColors.white),
            ),
          ],
        ),
        actions: [
          if (_currentRole == UserRole.superadmin)
            PopupMenuButton<String>(
              icon: const Icon(Icons.store, color: AppColors.gold),
              tooltip: 'Cambiar Restaurante',
              onSelected: (id) {
                setState(() {
                  _currentRestaurantId = id;
                  _currentCart.clear();
                });
              },
              itemBuilder: (_) => widget.restaurants
                  .map((r) => PopupMenuItem(value: r.id, child: Text(r.name)))
                  .toList(),
            ),
          IconButton(
            icon: const Icon(Icons.logout, color: AppColors.white),
            onPressed: () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const LoginScreen()),
            ),
          ),
        ],
      ),
      body: pages[_tabIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabIndex,
        indicatorColor: AppColors.goldLight,
        onDestinationSelected: (idx) => setState(() => _tabIndex = idx),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.point_of_sale), label: 'Comandas'),
          NavigationDestination(icon: Icon(Icons.soup_kitchen), label: 'Cocina'),
          NavigationDestination(icon: Icon(Icons.inventory_2), label: 'Inventario'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Ventas / Admin'),
        ],
      ),
    );
  }

  String _selectedCategory = 'AL PLATO';

  Widget _buildPosTab() {
    final categories = ['AL PLATO', 'SÁNDWICHES', 'TACOS Y ENCHILADAS', 'BEBIDAS'];
    final filteredMenu = _menu.where((p) => p.category == _selectedCategory).toList();
    final cartTotal = _currentCart.fold<double>(0, (s, i) => s + i.subtotal);

    return Column(
      children: [
        Container(
          color: AppColors.primaryGreen,
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: categories.map((cat) {
                final selected = _selectedCategory == cat;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: ChoiceChip(
                    label: Text(cat, style: const TextStyle(fontWeight: FontWeight.bold)),
                    selected: selected,
                    selectedColor: AppColors.gold,
                    backgroundColor: AppColors.darkGreen,
                    labelStyle: TextStyle(
                      color: selected ? AppColors.primaryGreen : AppColors.white,
                    ),
                    onSelected: (_) => setState(() => _selectedCategory = cat),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(10),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 1.45,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            itemCount: filteredMenu.length,
            itemBuilder: (_, idx) {
              final prod = filteredMenu[idx];
              return InkWell(
                onTap: () => _openProductCustomizer(prod),
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.grey.shade300),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.04),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        prod.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 15,
                          color: AppColors.textDark,
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: AppColors.lightGreen,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              'S/ ${prod.basePrice.toStringAsFixed(2)}',
                              style: const TextStyle(
                                fontWeight: FontWeight.w900,
                                color: AppColors.primaryGreen,
                              ),
                            ),
                          ),
                          const Icon(Icons.add_circle, color: AppColors.primaryGreen, size: 26),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        if (_currentCart.isNotEmpty)
          Container(
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(
              color: AppColors.primaryGreen,
              borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  height: 76,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: _currentCart.length,
                    itemBuilder: (_, i) {
                      final line = _currentCart[i];
                      return Container(
                        width: 210,
                        margin: const EdgeInsets.only(right: 8),
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppColors.darkGreen,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppColors.gold.withOpacity(0.5)),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    '${line.quantity}x ${line.productName}',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: AppColors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                    ),
                                  ),
                                  Text(
                                    [
                                      if (line.protein != null) line.protein!,
                                      if (line.fries != null) line.fries!,
                                      if (line.creams.isNotEmpty) '${line.creams.length} cremas',
                                    ].join(' • '),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(color: AppColors.gold, fontSize: 11),
                                  ),
                                  Text(
                                    'S/ ${line.subtotal.toStringAsFixed(2)}',
                                    style: const TextStyle(color: Colors.white70, fontSize: 11),
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.redAccent, size: 20),
                              onPressed: () => setState(() => _currentCart.removeAt(i)),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.gold,
                      foregroundColor: AppColors.primaryGreen,
                    ),
                    onPressed: _confirmOrderDialog,
                    icon: const Icon(Icons.send),
                    label: Text(
                      'CONFIRMAR COMANDA • S/ ${cartTotal.toStringAsFixed(2)}',
                      style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15),
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildKitchenTab() {
    final activeOrders = _orders.where((o) => o.status != OrderStatus.anulado).toList();
    if (activeOrders.isEmpty) {
      return const Center(
        child: Text('No hay comandas registradas aún.', style: TextStyle(fontSize: 16)),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: activeOrders.length,
      itemBuilder: (_, idx) {
        final order = activeOrders[idx];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: const BorderSide(color: AppColors.primaryGreen, width: 1.5),
          ),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'COMANDA #${order.orderNumber} • ${order.tableOrClient}',
                      style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                        color: AppColors.primaryGreen,
                      ),
                    ),
                    Chip(
                      backgroundColor: AppColors.goldLight,
                      label: Text(
                        order.status.name.toUpperCase(),
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: AppColors.primaryGreen,
                          fontSize: 11,
                        ),
                      ),
                    ),
                  ],
                ),
                Text(
                  'Hora: ${order.createdAt.hour.toString().padLeft(2, '0')}:${order.createdAt.minute.toString().padLeft(2, '0')} • ${order.isTakeaway ? "PARA LLEVAR" : "MESA"}',
                  style: const TextStyle(color: Colors.grey, fontSize: 12),
                ),
                const Divider(),
                ...order.items.map((item) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${item.quantity}x ${item.productName}',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                        ),
                        if (item.protein != null)
                          Text('• Proteína: ${item.protein}', style: const TextStyle(fontSize: 13)),
                        if (item.fries != null)
                          Text('• Papas: ${item.fries}', style: const TextStyle(fontSize: 13)),
                        if (item.broasterRice != null)
                          Text(
                            '• Broaster: ${item.broasterRice} / ${item.broasterSalad}',
                            style: const TextStyle(fontSize: 13),
                          ),
                        if (item.creams.isNotEmpty)
                          Text(
                            '• Cremas: ${item.creams.join(", ")}',
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: AppColors.primaryGreen,
                            ),
                          ),
                        if (item.quickNote.isNotEmpty)
                          Text(
                            '• Nota: ${item.quickNote}',
                            style: const TextStyle(fontSize: 13, color: AppColors.danger),
                          ),
                      ],
                    ),
                  );
                }),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  children: [
                    _statusBtn(order, OrderStatus.pendiente, 'Pendiente'),
                    _statusBtn(order, OrderStatus.enPreparacion, 'En preparación'),
                    _statusBtn(order, OrderStatus.listo, 'Listo'),
                    _statusBtn(order, OrderStatus.entregado, 'Entregado'),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _statusBtn(CustomerOrder order, OrderStatus st, String label) {
    final active = order.status == st;
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: active ? AppColors.primaryGreen : Colors.grey.shade200,
        foregroundColor: active ? AppColors.gold : AppColors.textDark,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      ),
      onPressed: () => setState(() => order.status = st),
      child: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildInventoryTab() {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        const Text(
          'EXISTENCIAS EN TIEMPO REAL',
          style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.primaryGreen, fontSize: 16),
        ),
        const SizedBox(height: 8),
        ..._inventory.map((inv) {
          final isLow = inv.stock <= inv.minAlert;
          return Card(
            color: isLow ? Colors.red.shade50 : AppColors.white,
            child: ListTile(
              title: Text(inv.name, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('Mínimo alerta: ${inv.minAlert} ${inv.unit}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    '${inv.stock.toStringAsFixed(2)} ${inv.unit}',
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 15,
                      color: isLow ? AppColors.danger : AppColors.primaryGreen,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.add_box, color: AppColors.primaryGreen),
                    tooltip: 'Registrar Compra / Entrada',
                    onPressed: () {
                      setState(() {
                        inv.stock += 10;
                        _logs.insert(
                          0,
                          InventoryLog(
                            date: DateTime.now(),
                            itemName: inv.name,
                            type: 'Compra / Entrada (+10)',
                            change: 10,
                            stockAfter: inv.stock,
                            user: widget.username,
                          ),
                        );
                      });
                    },
                  ),
                ],
              ),
            ),
          );
        }),
        const SizedBox(height: 16),
        const Text(
          'ÚLTIMOS MOVIMIENTOS DE INVENTARIO',
          style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.primaryGreen, fontSize: 16),
        ),
        const SizedBox(height: 8),
        ..._logs.take(15).map(
              (log) => ListTile(
                dense: true,
                leading: Icon(
                  log.change >= 0 ? Icons.arrow_downward : Icons.arrow_upward,
                  color: log.change >= 0 ? Colors.green : AppColors.danger,
                ),
                title: Text('${log.itemName} (${log.type})'),
                subtitle: Text('Usuario: ${log.user} • Saldo: ${log.stockAfter.toStringAsFixed(2)}'),
                trailing: Text(
                  '${log.change >= 0 ? "+" : ""}${log.change.toStringAsFixed(2)}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
      ],
    );
  }

  Widget _buildSalesAndAdminTab() {
    final validOrders = _orders.where((o) => o.status != OrderStatus.anulado).toList();
    final totalSales = validOrders.fold<double>(0, (s, o) => s + o.total);

    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Card(
          color: AppColors.primaryGreen,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: [
                const Text('TOTAL VENDIDO HOY', style: TextStyle(color: AppColors.white)),
                const SizedBox(height: 6),
                Text(
                  'S/ ${totalSales.toStringAsFixed(2)}',
                  style: const TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.w900,
                    color: AppColors.gold,
                  ),
                ),
                Text(
                  'Comandas válidas: ${validOrders.length}',
                  style: const TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
        ),
        if (_currentRole == UserRole.superadmin) ...[
          const SizedBox(height: 12),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.gold,
              foregroundColor: AppColors.primaryGreen,
              minimumSize: const Size(double.infinity, 48),
            ),
            icon: const Icon(Icons.add_business),
            label: const Text('REGISTRAR NUEVO RESTAURANTE', style: TextStyle(fontWeight: FontWeight.bold)),
            onPressed: () {
              final newId = 'rest_${widget.restaurants.length + 1}';
              setState(() {
                widget.restaurants.add(
                  Restaurant(
                    id: newId,
                    name: 'Caito Food - Sucursal #${widget.restaurants.length + 1}',
                    address: 'Nueva Sede',
                  ),
                );
                _initTenantData(newId);
                _currentRestaurantId = newId;
              });
            },
          ),
        ],
        const SizedBox(height: 16),
        const Text(
          'HISTORIAL DE COMANDAS',
          style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.primaryGreen, fontSize: 16),
        ),
        const SizedBox(height: 8),
        ..._orders.map((ord) {
          final isCancelled = ord.status == OrderStatus.anulado;
          return Card(
            color: isCancelled ? Colors.grey.shade200 : AppColors.white,
            child: ListTile(
              title: Text(
                'Comanda #${ord.orderNumber} - S/ ${ord.total.toStringAsFixed(2)}',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  decoration: isCancelled ? TextDecoration.lineThrough : null,
                ),
              ),
              subtitle: Text(
                '${ord.tableOrClient} • Pago: ${ord.paymentMethod} • Estado: ${ord.status.name}',
              ),
              trailing: (!isCancelled &&
                      (_currentRole == UserRole.admin || _currentRole == UserRole.superadmin))
                  ? IconButton(
                      icon: const Icon(Icons.cancel, color: AppColors.danger),
                      tooltip: 'Anular venta y revertir inventario',
                      onPressed: () {
                        setState(() {
                          ord.status = OrderStatus.anulado;
                          for (final line in ord.items) {
                            line.totalRecipePerUnit.forEach((ingId, reqPerUnit) {
                              final inv = _inventory.firstWhere((i) => i.id == ingId);
                              final restore = reqPerUnit * line.quantity;
                              inv.stock += restore;
                              _logs.insert(
                                0,
                                InventoryLog(
                                  date: DateTime.now(),
                                  itemName: inv.name,
                                  type: 'Anulación Comanda #${ord.orderNumber}',
                                  change: restore,
                                  stockAfter: inv.stock,
                                  user: widget.username,
                                ),
                              );
                            });
                          }
                        });
                      },
                    )
                  : null,
            ),
          );
        }),
      ],
    );
  }
}
