# COMANDA CAITO FOOD

Proyecto base en Flutter para sistema POS multi-restaurante, comandas, cocina, inventario y ventas.

## Archivos incluidos
- `.github/workflows/build-apk.yml`: Workflow automático en GitHub Actions para compilar el APK de Android.
- `pubspec.yaml`: Configuración de dependencias de Flutter.
- `lib/main.dart`: Código fuente principal de la aplicación.
- `database/schema_y_seed.sql`: Estructura base de base de datos PostgreSQL / Supabase.
