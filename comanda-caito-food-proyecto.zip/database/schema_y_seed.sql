CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TYPE user_role AS ENUM ('superadmin', 'admin', 'cajero', 'cocina');
CREATE TYPE order_type AS ENUM ('mesa', 'llevar');
CREATE TYPE order_status AS ENUM ('pendiente', 'en_preparacion', 'listo', 'entregado', 'anulado');
CREATE TYPE payment_method AS ENUM ('efectivo', 'yape', 'plin', 'tarjeta', 'transferencia', 'pendiente');

CREATE TABLE restaurants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(120) NOT NULL,
    address TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    daily_order_sequence INT NOT NULL DEFAULT 0,
    last_sequence_date DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    restaurant_id UUID REFERENCES restaurants(id) ON DELETE CASCADE,
    full_name VARCHAR(120) NOT NULL,
    username VARCHAR(60) UNIQUE NOT NULL,
    role user_role NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    name VARCHAR(80) NOT NULL,
    sort_order INT NOT NULL DEFAULT 0
);

CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    category_id UUID NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
    name VARCHAR(120) NOT NULL,
    base_price NUMERIC(10, 2) NOT NULL,
    requires_protein BOOLEAN NOT NULL DEFAULT FALSE,
    requires_fries BOOLEAN NOT NULL DEFAULT FALSE,
    requires_broaster_opts BOOLEAN NOT NULL DEFAULT FALSE,
    allows_creams BOOLEAN NOT NULL DEFAULT TRUE,
    is_available BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE orders (
    id UUID PRIMARY KEY,
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    order_number INT NOT NULL,
    order_type order_type NOT NULL,
    table_or_client VARCHAR(60),
    status order_status NOT NULL DEFAULT 'pendiente',
    payment_method payment_method NOT NULL DEFAULT 'efectivo',
    total NUMERIC(10, 2) NOT NULL,
    created_by UUID NOT NULL REFERENCES user_profiles(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE order_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES products(id),
    product_name VARCHAR(120) NOT NULL,
    quantity INT NOT NULL,
    unit_price NUMERIC(10, 2) NOT NULL,
    protein VARCHAR(60),
    fries VARCHAR(60),
    broaster_rice VARCHAR(40),
    broaster_salad VARCHAR(40),
    creams TEXT[] NOT NULL DEFAULT '{}',
    quick_note VARCHAR(150)
);
